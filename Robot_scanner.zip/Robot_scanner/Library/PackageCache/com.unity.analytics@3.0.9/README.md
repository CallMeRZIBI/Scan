Unity Analytics: Tracker
------------------------------
Please visit the following URL to see documentation for the Analytics Event Tracker.

https://docs.google.com/document/d/1glh4zEk0KQ_FhOgk95H-VOubcdzrVGyu5BYCmhFQCh0/edit#

Please note, the documentation at this URL is considered a "living" document and subject to change.


Unity Analytics: Standard Events
------------------------------
Track player behavior specific to your game

Standard Events are a set of curated custom events focused on player experience.
