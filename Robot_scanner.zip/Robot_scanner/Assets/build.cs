﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;

public class build : MonoBehaviour
{
    public float spawntime = 2;
    public GameObject Sphere_new;
    private float nexttimetospawn = 0f;

    float xn = 0;
    float yn = 0;

    // Update is called once per frame
    void Update()
    {
        if(Time.time >= nexttimetospawn)
        {
            string newtext = File.ReadAllText(@"here choose your file" + "\\data.txt");
            string x = getBetween(newtext, "/s", "/t");
            string y = getBetween(newtext, "/t", "/z");
            string z = getBetween(newtext, "/k", "/s");
            float xx = Convert.ToSingle(x);
            float yy = Convert.ToSingle(y);
            float zz = Convert.ToSingle(z);
            if(xx != xn || yy != yn)
            {
                xn = xx;
                yn = yy;
                Instantiate(Sphere_new, new Vector3(xx, zz, yy), Quaternion.identity);
                Debug.Log(zz);
                nexttimetospawn = Time.time + 1f / spawntime;
            }
            else
            {
                nexttimetospawn = Time.time + 1f / spawntime;
            }

        }
    }
    public static string getBetween(string strSource, string strStart, string strEnd)
    {
        int Start, End;
        if (strSource.Contains(strStart) && strSource.Contains(strEnd))
        {
            Start = strSource.IndexOf(strStart, 0) + strStart.Length;
            End = strSource.IndexOf(strEnd, Start);
            return strSource.Substring(Start, End - Start);
        }
        else
        {
            return "";
        }
    }
}
